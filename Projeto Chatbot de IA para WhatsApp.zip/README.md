# Elite Barbearia — pacote n8n

Este pacote é um esqueleto modular de produção, mas NÃO está pronto para operar clientes reais sem configuração e validação.

## Ordem sugerida
1. Configure PostgreSQL e execute `database_schema.sql`.
2. Crie a credencial PostgreSQL no n8n e substitua os IDs de credenciais nos nós.
3. Defina o provedor oficial de WhatsApp e configure `WHATSAPP_SEND_URL` + `WHATSAPP_API_TOKEN`.
4. Obtenha a documentação/credenciais da API do AppBarber.
5. Substitua SOMENTE os placeholders AppBarber pelos endpoints/campos confirmados na documentação.
6. Defina o provedor/modelo de IA e `LLM_GATEWAY_URL`, `LLM_API_KEY`, `LLM_MODEL`.
7. Importe os workflows individualmente no n8n.
8. Troque os `WORKFLOW_*_PLACEHOLDER` pelos IDs reais dos workflows depois da importação.
9. Teste primeiro em números/contas de teste e com agendamentos de teste.
10. Só depois habilite produção.

## Placeholders críticos
- `APPBARBER_*`: NÃO são endpoints reais. Validar na API do AppBarber.
- `WHATSAPP_SEND_URL`: NÃO assume um provedor específico.
- `LLM_GATEWAY_URL`: endpoint genérico do provedor de IA escolhido.
- `POSTGRES_CREDENTIAL_PLACEHOLDER`: criar credencial no n8n.
- `WORKFLOW_*_PLACEHOLDER`: substituir pelos IDs reais após importar os workflows.

## Observação importante sobre follow-up/reativação
O fluxo mantém follow-up de conversas recentes separado da reativação de clientes antigos. Antes de qualquer mensagem iniciada pela empresa, implemente as regras do provedor oficial de WhatsApp, templates quando exigidos e opt-out.

## Máquina de estados recomendada
new -> in_service -> interested -> awaiting_choice -> scheduled
in_service -> not_completed -> follow_up_pending -> follow_up_sent -> in_service
active -> inactive -> reactivation_pending -> reactivation_sent -> responded
qualquer estado -> human

Os workflows são uma base inicial. A etapa de "aguardar resposta do cliente" deve ser resolvida pelo armazenamento de estado + próxima mensagem recebida; não por um Wait infinito.
